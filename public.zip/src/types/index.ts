export type Plan = 'radar' | 'pulse' | 'command'

export type DeadlineType =
  | 'tugas'
  | 'praktikum'
  | 'kuis'
  | 'ujian'
  | 'presentasi'
  | 'administrasi'
  | 'pembayaran'
  | 'organisasi'
  | 'lainnya'

export type DeadlineSource =
  | 'vclass'
  | 'ilab'
  | 'dosen_langsung'
  | 'grup_wa'
  | 'praktikum'
  | 'studentsite'
  | 'baak'
  | 'lepkom'
  | 'lainnya'

export type DeadlineStatus = 'pending' | 'in_progress' | 'completed' | 'overdue'
export type DeadlinePriority = 'low' | 'normal' | 'high' | 'urgent'
export type ReminderChannel = 'telegram' | 'whatsapp'
export type SubscriptionIntentStatus = 'pending' | 'confirmed' | 'rejected' | 'cancelled'

export interface Profile {
  id: string
  email: string
  founder_verified?: boolean | null
  full_name: string | null
  campus_name: string | null
  province: string | null
  major: string | null
  semester: number | null
  gender: 'laki_laki' | 'perempuan' | 'lainnya' | 'tidak_ingin_menyebutkan' | null
  avatar_icon: string | null
  avatar_url: string | null
  student_id: string | null
  phone_number: string | null
  telegram_chat_id: string | null
  whatsapp_number: string | null
  plan: Plan
  plan_expires_at?: string | null
  subscription_expires_at?: string | null
  command_expires_at?: string | null
  lifetime_command?: boolean | null
  referral_code: string | null
  nexa_id: string | null
  pulse_trial_until: string | null
  is_public_profile: boolean | null
  badges: string[] | null
  online_status_visibility: 'public' | 'friends' | 'private' | null
  study_room_presence_visibility: 'members' | 'private' | null
  dm_privacy: 'friends' | 'none' | null
  featured_badge: string | null
  public_profile_headline: string | null
  profile_bio: string | null
  profile_bio_visibility: 'public' | 'private' | null
  profile_skills: string[] | null
  profile_skills_visibility: 'public' | 'private' | null
  profile_interests: string[] | null
  profile_interests_visibility: 'public' | 'private' | null
  portfolio_url: string | null
  github_url: string | null
  linkedin_url: string | null
  profile_completed: boolean
  created_at: string
  updated_at: string
}

export interface LeaderboardEntry {
  user_id: string
  email?: string | null
  founder_verified?: boolean | null
  display_name: string | null
  avatar_url: string | null
  campus_name: string | null
  featured_badge?: string | null
  plan: Plan
  plan_expires_at?: string | null
  subscription_expires_at?: string | null
  lifetime_command?: boolean | null
  points: number
  rank: number
}

export interface LeaderboardMe {
  points: number
  rank: number | null
  total_players: number
  current_streak: number
  is_public: boolean
}

export type LeaderboardScope = 'weekly' | 'monthly' | 'all_time'

// ---------- Study Room -------------------------------------------------------
export type StudyRoomCategory =
  | 'umum' | 'matematika' | 'fisika' | 'kimia' | 'biologi'
  | 'informatika' | 'ekonomi' | 'hukum' | 'kedokteran' | 'bahasa' | 'seni' | 'lainnya'

export type RoomMemberRole = 'owner' | 'admin' | 'moderator' | 'member'

export interface StudyRoom {
  id: string
  owner_id: string
  room_code: string
  title: string
  description: string | null
  topic: string | null
  category: StudyRoomCategory
  cover_url: string | null
  max_members: number
  current_members_count: number
  status: 'open' | 'full' | 'closed'
  visibility: 'public' | 'private'
  scheduled_at: string | null
  created_at: string
  updated_at: string
  owner_name?: string | null
  is_member?: boolean
  member_role?: RoomMemberRole | null
  has_pending_request?: boolean
}

export interface StudyRoomMember {
  id: string
  room_id: string
  user_id: string
  role: RoomMemberRole
  joined_at: string
  profile?: PublicProfile | null
}

export interface StudyRoomJoinRequest {
  id: string
  room_id: string
  user_id: string
  status: 'pending' | 'approved' | 'rejected'
  message: string | null
  created_at: string
  updated_at: string
  user?: PublicProfile | null
}

export interface ArenaTeamMember {
  id: string
  post_id: string
  user_id: string
  role: 'creator' | 'member'
  joined_at: string
  profile?: PublicProfile | null
}

export interface StudyRoomMessage {
  id: string
  room_id: string
  sender_id: string
  content: string | null
  message_type: 'text' | 'image' | 'video' | 'file'
  attachment_path: string | null
  attachment_name: string | null
  attachment_size: number | null
  attachment_mime: string | null
  edited_at?: string | null
  deleted_at?: string | null
  created_at: string
  sender?: PublicProfile | null
}

// ---------- Friends ----------------------------------------------------------
export interface PublicProfile {
  id: string
  email?: string | null
  founder_verified?: boolean | null
  full_name: string | null
  campus_name: string | null
  major: string | null
  avatar_url: string | null
  plan: Plan
  nexa_id: string | null
  featured_badge?: string | null
  public_profile_headline?: string | null
  profile_bio?: string | null
  profile_bio_visibility?: 'public' | 'private' | null
  profile_skills?: string[] | null
  profile_skills_visibility?: 'public' | 'private' | null
  profile_interests?: string[] | null
  profile_interests_visibility?: 'public' | 'private' | null
  portfolio_url?: string | null
  github_url?: string | null
  linkedin_url?: string | null
  online_status_visibility?: 'public' | 'friends' | 'private' | null
  study_room_presence_visibility?: 'members' | 'private' | null
  dm_privacy?: 'friends' | 'none' | null
  last_seen_at?: string | null
  friend_count?: number | null
  badges?: string[] | null
  created_at: string
}

export interface PrivateMessage {
  id: string
  sender_id: string
  receiver_id: string
  content: string | null
  message_type: 'text' | 'image' | 'video' | 'file'
  attachment_path: string | null
  attachment_name: string | null
  attachment_size: number | null
  attachment_mime: string | null
  edited_at: string | null
  deleted_at: string | null
  created_at: string
  sender?: PublicProfile | null
}

export type FriendRequestStatus = 'pending' | 'accepted' | 'rejected'

export interface FriendRequest {
  id: string
  requester_id: string
  receiver_id: string
  status: FriendRequestStatus
  created_at: string
  updated_at: string
  other_user?: PublicProfile | null
}

export interface Referral {
  id: string
  referrer_id: string
  referred_id: string
  created_at: string
  rewarded: boolean
}

export interface AcademicDeadline {
  id: string
  user_id: string
  title: string | null
  course_name: string
  type: DeadlineType
  source: DeadlineSource
  deadline_date: string
  deadline_time: string
  campus: string
  room: string
  location_note: string | null
  notes: string | null
  status: DeadlineStatus
  priority: DeadlinePriority
  reminder_enabled: boolean
  is_recurring: boolean
  recurrence_day_of_week: number | null
  recurrence_parent_id: string | null
  reminder_offset_minutes: number | null
  created_at: string
  updated_at: string
}

export interface ReminderPreferences {
  id: string
  user_id: string
  channel: ReminderChannel
  h7_enabled: boolean
  h3_enabled: boolean
  h1_enabled: boolean
  day_enabled: boolean
  reminder_time: string
  created_at: string
  updated_at: string
}

export interface SubscriptionIntent {
  id: string
  user_id: string
  requested_plan: Exclude<Plan, 'radar'>
  status: SubscriptionIntentStatus
  payment_method: 'manual_transfer' | 'qris'
  contact_note: string | null
  created_at: string
  updated_at: string
}

// ---------- Calendar Notes ---------------------------------------------------
export interface CalendarNote {
  id: string
  user_id: string
  /** Target date for this note in YYYY-MM-DD format. */
  note_date: string
  title: string | null
  content: string
  created_at: string
  updated_at: string
}