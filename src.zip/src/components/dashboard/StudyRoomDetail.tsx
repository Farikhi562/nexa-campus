'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  Check, ChevronLeft, Copy, Crown, Edit2, FileText, Image as ImageIcon,
  Loader2, LogOut, MoreVertical, Paperclip, Radio, Send, Settings, Shield, Smile, Trash2, UserMinus, UserPlus, Users, X
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent } from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Button from '@/components/ui/Button'
import type { StudyRoom, StudyRoomMember, StudyRoomMessage, StudyRoomJoinRequest, RoomMemberRole } from '@/types'
import Link from 'next/link'
import FounderVerifiedBadge from '@/components/FounderVerifiedBadge'
import StudyRoomWorkspaceCard from '@/components/dashboard/StudyRoomWorkspaceCard'
import StudyRoomCommandActions from '@/components/study-room/StudyRoomCommandActions'

function initials(name?: string | null) {
  if (!name) return 'N'
  const p = name.trim().split(/\s+/)
  return ((p[0]?.[0] ?? '') + (p[1]?.[0] ?? '')).toUpperCase() || 'N'
}

function Avatar({ url, name, size = 'md' }: { url?: string | null; name?: string | null; size?: 'sm' | 'md' | 'lg' }) {
  const s = size === 'sm' ? 'h-7 w-7 text-[10px]' : size === 'lg' ? 'h-12 w-12 text-base' : 'h-9 w-9 text-xs'
  return (
    <span className={`flex ${s} flex-shrink-0 items-center justify-center overflow-hidden rounded-xl bg-slate-100 font-black text-slate-600`}>
      {url ? <img src={url} alt="" className="h-full w-full object-cover" /> : initials(name)}
    </span>
  )
}

function RoleBadge({ role }: { role: RoomMemberRole }) {
  const styles: Record<RoomMemberRole, string> = {
    owner: 'bg-amber-100 text-amber-700',
    admin: 'bg-teal-100 text-teal-700',
    moderator: 'bg-blue-100 text-blue-700',
    member: 'bg-slate-100 text-slate-600',
  }
  const labels: Record<RoomMemberRole, string> = { owner: 'Owner', admin: 'Admin', moderator: 'Mod', member: 'Member' }
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-black ${styles[role]}`}>
      {role === 'owner' && <Crown className="h-2.5 w-2.5" />}
      {role === 'admin' && <Shield className="h-2.5 w-2.5" />}
      {labels[role]}
    </span>
  )
}

function formatTime(dateStr: string) {
  const d = new Date(dateStr)
  const now = new Date()
  const isToday = d.toDateString() === now.toDateString()
  if (isToday) return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

const EMOJIS = ['🔥', '😂', '👍', '🥲', '😭', '🚀', '✅', '💀']

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

export default function StudyRoomDetail({ roomId, userId }: { roomId: string; userId: string }) {
  const router = useRouter()
  const supabase = useMemo(() => createClient(), [])
  const [room, setRoom] = useState<StudyRoom | null>(null)
  const [messages, setMessages] = useState<StudyRoomMessage[]>([])
  const [members, setMembers] = useState<StudyRoomMember[]>([])
  const [joinRequests, setJoinRequests] = useState<StudyRoomJoinRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [mobileTab, setMobileTab] = useState<'chat' | 'members'>('chat')
  const [message, setMessage] = useState('')
  const [sending, setSending] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [onlineMemberIds, setOnlineMemberIds] = useState<Set<string>>(new Set())
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingText, setEditingText] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const membersRef = useRef<StudyRoomMember[]>([])
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const typingTimeoutRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({})
  const [typingUsers, setTypingUsers] = useState<Record<string, string>>({}) // userId → name
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://campus.nexatechlabs.my.id'

  // Selalu update ref ke nilai terbaru supaya realtime callback tidak stale
  useEffect(() => { membersRef.current = members }, [members])

  const myMembership = members.find((m) => m.user_id === userId)
  const myRole = myMembership?.role ?? null
  const canManage = myRole === 'owner' || myRole === 'admin'
  const myRoomPresenceVisibility = myMembership?.profile?.study_room_presence_visibility ?? 'members'

  const loadAll = useCallback(async () => {
    setLoading(true)
    const [roomRes, msgRes, memberRes] = await Promise.all([
      fetch(`/api/study-rooms/${roomId}`, { cache: 'no-store' }),
      fetch(`/api/study-rooms/${roomId}/messages?limit=50`, { cache: 'no-store' }),
      fetch(`/api/study-rooms/${roomId}/members`, { cache: 'no-store' }),
    ])
    const [roomJson, msgJson, memberJson] = await Promise.all([roomRes.json(), msgRes.json(), memberRes.json()])
    if (!roomRes.ok) { setError(roomJson.error ?? 'Room tidak ditemukan.'); setLoading(false); return }
    setRoom(roomJson.data)
    setMessages(msgRes.ok ? (msgJson.data ?? []) : [])
    setMembers(memberRes.ok ? (memberJson.data ?? []) : [])
    setLoading(false)
  }, [roomId])

  const loadJoinRequests = useCallback(async () => {
    if (!canManage) return
    const res = await fetch(`/api/study-rooms/${roomId}/requests`, { cache: 'no-store' })
    const json = await res.json()
    if (res.ok) setJoinRequests(json.data ?? [])
  }, [roomId, canManage])

  useEffect(() => { void loadAll() }, [loadAll])
  useEffect(() => { void loadJoinRequests() }, [loadJoinRequests])

  // Satu channel untuk: postgres_changes (pesan baru/edit/hapus) + broadcast (typing) + presence (online member)
  useEffect(() => {
    const channel = supabase
      .channel(`study-room-${roomId}`, { config: { presence: { key: userId } } })
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'study_room_messages', filter: `room_id=eq.${roomId}` },
        (payload) => {
          const row = (payload.new || payload.old) as StudyRoomMessage | undefined
          if (!row) return
          const sender = membersRef.current.find((m) => m.user_id === row.sender_id)?.profile ?? null
          if (payload.eventType === 'INSERT') {
            setMessages((prev) => prev.find((m) => m.id === row.id) ? prev : [...prev, { ...row, sender }])
          } else if (payload.eventType === 'UPDATE') {
            setMessages((prev) => prev.map((m) => m.id === row.id ? { ...m, ...row, sender: m.sender ?? sender } : m))
          } else if (payload.eventType === 'DELETE') {
            setMessages((prev) => prev.filter((m) => m.id !== row.id))
          }
        })
      .on('broadcast', { event: 'typing' }, ({ payload }) => {
        const { sender_id, sender_name } = payload as { sender_id: string; sender_name: string }
        if (sender_id === userId) return
        setTypingUsers((prev) => ({ ...prev, [sender_id]: sender_name }))
        if (typingTimeoutRef.current[sender_id]) clearTimeout(typingTimeoutRef.current[sender_id])
        typingTimeoutRef.current[sender_id] = setTimeout(() => {
          setTypingUsers((prev) => {
            const next = { ...prev }
            delete next[sender_id]
            return next
          })
        }, 3000)
      })
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState()
        const ids = new Set<string>()
        Object.values(state).flat().forEach((presence) => {
          const user_id = (presence as { user_id?: string }).user_id
          if (user_id) ids.add(user_id)
        })
        setOnlineMemberIds(ids)
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED' && myRoomPresenceVisibility !== 'private') {
          void channel.track({ user_id: userId, online_at: new Date().toISOString() })
        }
      })

    channelRef.current = channel
    return () => {
      void supabase.removeChannel(channel)
      channelRef.current = null
      Object.values(typingTimeoutRef.current).forEach(clearTimeout)
    }
  }, [myRoomPresenceVisibility, roomId, supabase, userId])

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  async function sendMessage() {
    if (!message.trim() || sending) return
    setSending(true)
    const text = message.trim()
    setMessage('')
    const res = await fetch(`/api/study-rooms/${roomId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: text, message_type: 'text' }),
    })
    if (!res.ok) {
      const json = await res.json()
      setMessage(text)
      alert(json.error ?? 'Gagal kirim pesan.')
    }
    setSending(false)
  }

  async function sendFile(file: File) {
    setUploading(true)
    const formData = new FormData()
    formData.append('file', file)
    const upRes = await fetch(`/api/study-rooms/${roomId}/upload`, { method: 'POST', body: formData })
    const upJson = await upRes.json()
    if (!upRes.ok) { alert(upJson.error ?? 'Gagal upload file.'); setUploading(false); return }
    const att = upJson.data
    const msgRes = await fetch(`/api/study-rooms/${roomId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: att.filename,
        message_type: att.message_type,
        attachment_path: att.path,
        attachment_name: att.filename,
        attachment_size: att.file_size,
        attachment_mime: att.mime_type,
      }),
    })
    if (!msgRes.ok) { const j = await msgRes.json().catch(() => ({})); alert(j.error ?? 'Gagal kirim file.') }
    setUploading(false)
  }


  async function saveMessageEdit() {
    if (!editingId || !editingText.trim()) return
    const res = await fetch(`/api/study-rooms/${roomId}/messages/${editingId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: editingText.trim() }),
    })
    const json = await res.json().catch(() => ({}))
    if (res.ok && json.data) {
      setMessages((prev) => prev.map((m) => m.id === editingId ? { ...m, ...json.data } : m))
      setEditingId(null)
      setEditingText('')
    } else {
      alert(json.error ?? 'Gagal edit pesan.')
    }
  }

  async function deleteMessage(messageId: string) {
    if (!confirm('Hapus pesan ini? Foto/video/file juga akan dihapus dari chat.')) return
    const res = await fetch(`/api/study-rooms/${roomId}/messages/${messageId}`, { method: 'DELETE' })
    const json = await res.json().catch(() => ({}))
    if (res.ok && json.data) {
      setMessages((prev) => prev.map((m) => m.id === messageId ? { ...m, ...json.data } : m))
    } else {
      alert(json.error ?? 'Gagal hapus pesan.')
    }
  }

  async function handleJoinRequest(requestId: string, action: 'approve' | 'reject') {
    await fetch(`/api/study-rooms/${roomId}/requests/${requestId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
    })
    await loadJoinRequests()
    if (action === 'approve') await loadAll()
  }

  async function handleRoleChange(targetUserId: string, role: RoomMemberRole) {
    if (role === 'owner' && !confirm('Promosikan user ini jadi owner? Owner lama otomatis turun jadi admin. Ini bukan kerajaan, tapi tetap butuh konfirmasi.')) return
    const res = await fetch(`/api/study-rooms/${roomId}/members/${targetUserId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role }),
    })
    if (res.ok) await loadAll()
    else { const j = await res.json(); alert(j.error) }
  }

  async function handleRemoveMember(targetUserId: string) {
    if (!confirm('Keluarkan member ini?')) return
    const res = await fetch(`/api/study-rooms/${roomId}/members/${targetUserId}`, { method: 'DELETE' })
    if (res.ok) await loadAll()
    else { const j = await res.json(); alert(j.error) }
  }

  async function handleLeave() {
    if (!confirm(myRole === 'owner' ? 'Kamu owner. Kalau keluar, owner otomatis pindah ke admin/moderator/member lain. Kalau cuma kamu sendiri, room ditutup. Lanjut?' : 'Keluar dari room ini?')) return
    const res = await fetch(`/api/study-rooms/${roomId}/leave`, { method: 'POST' })
    if (res.ok) router.push('/dashboard/study-room')
    else { const j = await res.json(); alert(j.error) }
  }

  async function handleDeleteRoom() {
    if (!confirm('Hapus room ini secara permanen? Semua chat dan anggota akan hilang.')) return
    const res = await fetch(`/api/study-rooms/${roomId}`, { method: 'DELETE' })
    if (res.ok) router.push('/dashboard/study-room')
    else { const j = await res.json(); alert(j.error) }
  }

  function copyCode() {
    navigator.clipboard.writeText(room?.room_code ?? '')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function handleMessageInput(text: string) {
    setMessage(text)
    if (text.trim() && channelRef.current) {
      const myName = membersRef.current.find((m) => m.user_id === userId)?.profile?.full_name ?? 'Anggota'
      channelRef.current.send({ type: 'broadcast', event: 'typing', payload: { sender_id: userId, sender_name: myName } })
    }
  }

  function shareToWA() {
    if (!room) return
    const text = encodeURIComponent(
      `📚 Yuk belajar bareng di Study Room NEXA Campus!\n\nNama: ${room.title}\nKode Room: ${room.room_code}\n\nCara gabung:\n1. Buka NEXA Campus: ${siteUrl}/dashboard/study-room\n2. Masukkan kode: ${room.room_code}`
    )
    window.open(`https://wa.me/?text=${text}`, '_blank', 'noopener,noreferrer')
  }

  if (loading) return (
    <div className="flex h-[70vh] items-center justify-center text-slate-400">
      <Loader2 className="h-6 w-6 animate-spin" />
    </div>
  )
  if (error) return (
    <Card><CardContent className="p-8 text-center">
      <p className="text-red-600">{error}</p>
      <Link href="/dashboard/study-room" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-teal-700 underline">
        <ChevronLeft className="h-4 w-4" /> Kembali ke Study Room
      </Link>
    </CardContent></Card>
  )
  if (!room) return null

  if (!room.is_member) {
    return (
      <Card>
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col gap-5">
            {/* Room info header */}
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-2xl bg-slate-100 text-2xl">
                {room.visibility === 'private' ? '🔒' : '📚'}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-black ${
                    room.visibility === 'private' ? 'bg-amber-100 text-amber-700' : 'bg-teal-100 text-teal-700'
                  }`}>
                    {room.visibility === 'private' ? '🔒 Private' : '🌐 Publik'}
                  </span>
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-bold capitalize text-slate-600">
                    {room.category}
                  </span>
                  <span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
                    room.status === 'open' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {room.status === 'open' ? 'Buka' : room.status === 'full' ? 'Penuh' : 'Ditutup'}
                  </span>
                </div>
                <h2 className="mt-2 text-xl font-black text-slate-950">{room.title}</h2>
                {room.topic && <p className="mt-1 text-xs font-bold text-teal-600">#{room.topic}</p>}
              </div>
            </div>

            {/* Description */}
            {room.description && (
              <p className="text-sm leading-6 text-slate-600">{room.description}</p>
            )}

            {/* Stats */}
            <div className="flex flex-wrap gap-4 rounded-2xl border border-slate-100 bg-slate-50 p-4 text-sm">
              <div>
                <p className="text-xs text-slate-500">Anggota</p>
                <p className="font-black text-slate-950">{room.current_members_count}/{room.max_members}</p>
              </div>
              {(room as StudyRoom & { owner_name?: string }).owner_name && (
                <div>
                  <p className="text-xs text-slate-500">Dibuat oleh</p>
                  <p className="font-black text-slate-950">{(room as StudyRoom & { owner_name?: string }).owner_name}</p>
                </div>
              )}
              {room.scheduled_at && (
                <div>
                  <p className="text-xs text-slate-500">Jadwal</p>
                  <p className="font-black text-slate-950">
                    {new Date(room.scheduled_at).toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </p>
                </div>
              )}
            </div>

            {/* CTA */}
            {room.visibility === 'private' ? (
              <div className="space-y-3">
                {room.has_pending_request ? (
                  <div className="flex items-center justify-center gap-2 rounded-2xl border border-amber-200 bg-amber-50 py-3 text-sm font-black text-amber-700">
                    ⏳ Permintaan bergabung sedang diproses...
                  </div>
                ) : (
                  <button
                    onClick={async () => {
                      const res = await fetch(`/api/study-rooms/${roomId}/requests`, { method: 'POST' })
                      if (res.ok) { await loadAll() }
                      else { const j = await res.json(); alert(j.error ?? 'Gagal.') }
                    }}
                    className="focus-ring w-full rounded-2xl bg-teal-500 py-3 text-sm font-black text-white hover:bg-teal-400"
                  >
                    🔒 Minta Bergabung
                  </button>
                )}
                <p className="text-center text-xs text-slate-400">
                  Room ini private. Minta izin untuk bergabung terlebih dahulu.
                </p>
              </div>
            ) : (
              <button
                onClick={async () => {
                  const res = await fetch(`/api/study-rooms/${roomId}/join`, { method: 'POST' })
                  if (res.ok) { await loadAll() }
                  else { const j = await res.json(); alert(j.error ?? 'Gagal join.') }
                }}
                className="focus-ring w-full rounded-2xl bg-teal-500 py-3 text-sm font-black text-white hover:bg-teal-400"
              >
                Gabung Room
              </button>
            )}

            <Link href="/dashboard/study-room" className="flex items-center justify-center gap-1 text-sm font-bold text-slate-500 hover:text-slate-700">
              <ChevronLeft className="h-4 w-4" /> Kembali ke daftar room
            </Link>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <StudyRoomCommandActions />
      <div className="flex h-[calc(100vh-12rem)] flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl">
      {/* Header */}
      <div className="flex flex-shrink-0 items-center justify-between gap-3 border-b border-slate-100 bg-white px-4 py-3">
        <div className="flex min-w-0 items-center gap-3">
          <Link href="/dashboard/study-room" className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <div className="min-w-0">
            <h1 className="truncate text-base font-black text-slate-950">{room.title}</h1>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>{room.current_members_count}/{room.max_members} anggota</span>
              <span className="inline-flex items-center gap-1 text-emerald-600"><Radio className="h-3 w-3" /> {onlineMemberIds.size} online</span>
              <button onClick={copyCode} className="inline-flex items-center gap-1 rounded-lg bg-slate-100 px-2 py-0.5 font-black text-slate-700 hover:bg-slate-200">
                {copied ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                {room.room_code}
              </button>
              <button
                onClick={shareToWA}
                className="inline-flex items-center gap-1 rounded-lg bg-green-100 px-2 py-0.5 text-[11px] font-black text-green-700 hover:bg-green-200"
              >
                📲 Share WA
              </button>
              {room.visibility === 'private' && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-amber-700">Private</span>}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {canManage && joinRequests.length > 0 && (
            <button className="flex items-center gap-1 rounded-full bg-teal-100 px-2.5 py-1 text-xs font-black text-teal-700">
              <UserPlus className="h-3.5 w-3.5" /> {joinRequests.length}
            </button>
          )}
          <button onClick={() => setMobileTab(mobileTab === 'chat' ? 'members' : 'chat')}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100 lg:hidden">
            <Users className="h-5 w-5" />
          </button>
          {canManage && <button onClick={() => setShowSettings(true)} className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100">
            <Settings className="h-5 w-5" />
          </button>}
          <button onClick={handleLeave} className="flex h-9 w-9 items-center justify-center rounded-xl text-red-500 hover:bg-red-50">
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Main area */}
      <div className="flex min-h-0 flex-1 overflow-hidden">
        {/* Chat area */}
        <div className={`flex flex-1 flex-col overflow-hidden ${mobileTab === 'members' ? 'hidden lg:flex' : 'flex'}`}>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-center text-slate-400">
                <div className="text-5xl mb-3">💬</div>
                <p className="text-sm font-bold">Belum ada pesan.</p>
                <p className="text-xs mt-1">Mulai diskusi, atau minimal bilang halo dulu.</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.sender_id === userId
                return (
                  <div key={msg.id} className={`flex gap-2.5 ${isMe ? 'flex-row-reverse' : ''}`}>
                    <Avatar url={msg.sender?.avatar_url} name={msg.sender?.full_name} size="sm" />
                    <div className={`max-w-[75%] space-y-1 ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                      <p className={`text-[11px] font-bold text-slate-500 ${isMe ? 'text-right' : ''}`}>
                        <span className="inline-flex items-center gap-1">{isMe ? 'Kamu' : (msg.sender?.full_name ?? 'Anggota')} <FounderVerifiedBadge founderVerified={msg.sender?.founder_verified} email={msg.sender?.email} compact /></span> · {formatTime(msg.created_at)} {msg.edited_at && !msg.deleted_at ? '· diedit' : ''}
                      </p>
                      <div className={`rounded-2xl px-3.5 py-2.5 text-sm leading-6 ${
                        isMe ? 'rounded-tr-sm bg-teal-500 text-white' : 'rounded-tl-sm bg-slate-100 text-slate-900'
                      }`}>
                        {msg.deleted_at ? (
                          <p className="italic opacity-70">Pesan dihapus</p>
                        ) : editingId === msg.id ? (
                          <div className="space-y-2">
                            <textarea value={editingText} onChange={(e) => setEditingText(e.target.value)} rows={2} className="w-full rounded-xl border border-slate-200 px-3 py-2 text-slate-900" />
                            <div className="flex gap-2">
                              <button onClick={saveMessageEdit} className="rounded-xl bg-slate-950 px-3 py-1 text-xs font-black text-white">Simpan</button>
                              <button onClick={() => setEditingId(null)} className="rounded-xl bg-white/80 px-3 py-1 text-xs font-black text-slate-700">Batal</button>
                            </div>
                          </div>
                        ) : msg.message_type === 'image' && msg.attachment_path ? (
                          <div className="space-y-1">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={`${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/room-attachments/${msg.attachment_path}`}
                              alt={msg.attachment_name ?? 'Gambar'}
                              className="max-h-48 max-w-full rounded-xl object-cover"
                            />
                            <p className="text-[11px] opacity-70">{msg.attachment_name}</p>
                          </div>
                        ) : (msg.message_type === 'video' || msg.attachment_mime?.startsWith('video/')) && msg.attachment_path ? (
                          <div className="space-y-1">
                            <video controls className="max-h-48 max-w-full rounded-xl" preload="metadata">
                              <source
                                src={`${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/room-attachments/${msg.attachment_path}`}
                                type={msg.attachment_mime ?? 'video/mp4'}
                              />
                            </video>
                            <p className="text-[11px] opacity-70">{msg.attachment_name} {msg.attachment_size ? `(${formatBytes(msg.attachment_size)})` : ''}</p>
                          </div>
                        ) : msg.message_type === 'file' && msg.attachment_path ? (
                          <a
                            href={`${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/room-attachments/${msg.attachment_path}`}
                            target="_blank" rel="noopener noreferrer"
                            className="flex items-center gap-2 underline"
                          >
                            <FileText className="h-4 w-4 flex-shrink-0" />
                            <span>{msg.attachment_name}</span>
                            {msg.attachment_size && <span className="opacity-70">({formatBytes(msg.attachment_size)})</span>}
                          </a>
                        ) : (
                          <p>{msg.content}</p>
                        )}
                      </div>
                      {isMe && !msg.deleted_at && (
                        <div className="flex gap-1 opacity-80">
                          {msg.message_type === 'text' && (
                            <button onClick={() => { setEditingId(msg.id); setEditingText(msg.content ?? '') }} className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-black text-slate-600 hover:bg-slate-200">
                              <Edit2 className="inline h-3 w-3" /> Edit
                            </button>
                          )}
                          <button onClick={() => deleteMessage(msg.id)} className="rounded-full bg-red-50 px-2 py-1 text-[10px] font-black text-red-600 hover:bg-red-100">
                            <Trash2 className="inline h-3 w-3" /> Hapus
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Typing indicator */}
          {Object.keys(typingUsers).length > 0 && (
            <div className="flex-shrink-0 px-4 pb-1">
              <p className="flex items-center gap-2 text-xs text-slate-500">
                <span className="flex gap-0.5">
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.3s]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.15s]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400" />
                </span>
                {Object.values(typingUsers).join(', ')} sedang mengetik...
              </p>
            </div>
          )}

          {/* Chat input */}
          <div className="flex-shrink-0 border-t border-slate-100 p-3">
            <div className="mb-2 flex flex-wrap gap-1">
              {EMOJIS.map((emoji) => (
                <button key={emoji} type="button" onClick={() => setMessage((value) => `${value}${emoji}`)} className="rounded-xl bg-slate-100 px-2 py-1 text-sm hover:bg-slate-200">
                  {emoji}
                </button>
              ))}
            </div>
            <div className="flex items-end gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/mp4,video/webm,video/quicktime,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip"
                className="sr-only"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) void sendFile(f); e.target.value = '' }}
              />
              <button onClick={() => fileInputRef.current?.click()} disabled={uploading}
                className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl border border-slate-200 text-slate-500 hover:bg-slate-50 disabled:opacity-50">
                {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Paperclip className="h-4 w-4" />}
              </button>
              <textarea
                value={message}
                onChange={(e) => handleMessageInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void sendMessage() } }}
                placeholder="Kirim pesan... (Enter untuk kirim)"
                rows={1}
                className="focus-ring flex-1 resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm"
                style={{ minHeight: '2.5rem', maxHeight: '8rem' }}
              />
              <button onClick={sendMessage} disabled={!message.trim() || sending}
                className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl bg-teal-500 text-white transition hover:bg-teal-400 disabled:opacity-40">
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>

        {/* Members panel */}
        <div className={`${mobileTab === 'members' ? 'flex' : 'hidden lg:flex'} w-full flex-col overflow-hidden border-l border-slate-100 bg-slate-50/50 lg:w-72`}>
          {/* Join requests (for admins) */}
          {canManage && joinRequests.length > 0 && (
            <div className="flex-shrink-0 border-b border-slate-100 p-3">
              <p className="mb-2 text-xs font-black uppercase tracking-wide text-slate-500">
                Permintaan bergabung ({joinRequests.length})
              </p>
              <div className="space-y-2">
                {joinRequests.map((req) => (
                  <div key={req.id} className="flex items-center justify-between gap-2 rounded-2xl bg-white p-2.5 shadow-sm">
                    <div className="flex min-w-0 items-center gap-2">
                      <Avatar url={req.user?.avatar_url} name={req.user?.full_name} size="sm" />
                      <p className="flex min-w-0 items-center gap-1 truncate text-xs font-black text-slate-950"><span className="truncate">{req.user?.full_name ?? 'User'}</span><FounderVerifiedBadge founderVerified={req.user?.founder_verified} email={req.user?.email} compact /></p>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => handleJoinRequest(req.id, 'approve')}
                        className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 hover:bg-emerald-200">
                        <Check className="h-3.5 w-3.5" />
                      </button>
                      <button onClick={() => handleJoinRequest(req.id, 'reject')}
                        className="flex h-7 w-7 items-center justify-center rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-3">
            <p className="mb-2 text-xs font-black uppercase tracking-wide text-slate-500">
              Anggota ({members.length}) · {onlineMemberIds.size} online
            </p>
            <p className="mb-3 rounded-2xl bg-white p-2.5 text-[11px] leading-5 text-slate-500 shadow-sm">
Nama anggota selalu terlihat untuk satu grup room. Yang mengikuti privasi hanya status online. Kalau disembunyikan, dia tidak muncul online meski lagi di room. Chat pribadi tetap ikut pilihan masing-masing user.
            </p>
            <StudyRoomWorkspaceCard roomId={roomId} canManage={canManage} />

            <div className="space-y-1.5">
              {members.map((member) => (
                <div key={member.user_id} className="flex items-center justify-between gap-2 rounded-2xl bg-white p-2.5 shadow-sm">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="relative"><Avatar url={member.profile?.avatar_url} name={member.profile?.full_name} size="sm" />{onlineMemberIds.has(member.user_id) && member.profile?.study_room_presence_visibility !== 'private' && <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white bg-emerald-500" />}</span>
                    <div className="min-w-0">
                      <p className="flex min-w-0 items-center gap-1 truncate text-xs font-black text-slate-950">
                        <span className="truncate">{member.user_id === userId ? 'Kamu' : (member.profile?.full_name ?? 'Member')}</span>
                        <FounderVerifiedBadge founderVerified={member.profile?.founder_verified} email={member.profile?.email} compact />
                      </p>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5">
                        <RoleBadge role={member.role} />
                        {member.profile?.nexa_id && <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-black text-slate-500">#{member.profile.nexa_id}</span>}
                      </div>
                    </div>
                  </div>
                  {canManage && member.user_id !== userId && (myRole === 'owner' || member.role !== 'owner') && (
                    <div className="relative group">
                      <button className="flex h-7 w-7 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100">
                        <MoreVertical className="h-3.5 w-3.5" />
                      </button>
                      <div className="absolute right-0 top-8 z-10 hidden w-40 rounded-2xl border border-slate-200 bg-white p-1 shadow-xl group-hover:block">
                        {myRole === 'owner' && (
                          <>
                            {member.role !== 'owner' && (
                              <button onClick={() => handleRoleChange(member.user_id, 'owner')}
                                className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-amber-700 hover:bg-amber-50">
                                <Crown className="h-3.5 w-3.5" /> Promosikan Owner
                              </button>
                            )}
                            {member.role !== 'admin' && (
                              <button onClick={() => handleRoleChange(member.user_id, 'admin')}
                                className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50">
                                <Shield className="h-3.5 w-3.5" /> Jadikan Admin
                              </button>
                            )}
                            {member.role !== 'moderator' && (
                              <button onClick={() => handleRoleChange(member.user_id, 'moderator')}
                                className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50">
                                <Shield className="h-3.5 w-3.5" /> Jadikan Moderator
                              </button>
                            )}
                            {member.role !== 'member' && (
                              <button onClick={() => handleRoleChange(member.user_id, 'member')}
                                className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50">
                                <UserMinus className="h-3.5 w-3.5" /> Turunkan ke Member
                              </button>
                            )}
                          </>
                        )}
                        <button onClick={() => handleRemoveMember(member.user_id)}
                          className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-red-600 hover:bg-red-50">
                          <UserMinus className="h-3.5 w-3.5" /> Keluarkan
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {myRole === 'owner' && (
            <div className="flex-shrink-0 border-t border-slate-100 p-3">
              <button onClick={handleDeleteRoom}
                className="flex w-full items-center justify-center gap-2 rounded-2xl border border-red-200 bg-red-50 py-2.5 text-xs font-black text-red-600 hover:bg-red-100">
                <Trash2 className="h-4 w-4" /> Hapus Room
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Settings modal */}
      {showSettings && room && (
        <RoomSettingsModal
          room={room}
          onClose={() => setShowSettings(false)}
          onSaved={() => { setShowSettings(false); void loadAll() }}
        />
      )}
      </div>
    </div>
  )
}

function RoomSettingsModal({ room, onClose, onSaved }: { room: StudyRoom; onClose: () => void; onSaved: () => void }) {
  const [title, setTitle] = useState(room.title)
  const [description, setDescription] = useState(room.description ?? '')
  const [topic, setTopic] = useState(room.topic ?? '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    if (!title.trim()) { setError('Judul wajib diisi.'); return }
    setSaving(true)
    const res = await fetch(`/api/study-rooms/${room.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: title.trim(), description: description.trim() || null, topic: topic.trim() || null }),
    })
    const json = await res.json()
    setSaving(false)
    if (!res.ok) { setError(json.error ?? 'Gagal menyimpan.'); return }
    onSaved()
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center" onClick={onClose}>
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm" />
      <div className="relative z-10 w-full max-w-md rounded-t-3xl border border-slate-200 bg-white p-5 shadow-2xl sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-black text-slate-950">Pengaturan Room</h2>
          <button onClick={onClose} className="rounded-xl p-1.5 text-slate-500 hover:bg-slate-100"><X className="h-5 w-5" /></button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-black uppercase tracking-wide text-slate-600">Nama Room</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} className="focus-ring w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-black uppercase tracking-wide text-slate-600">Topik</label>
            <input value={topic} onChange={(e) => setTopic(e.target.value)} className="focus-ring w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm" placeholder="cth: kalkulus-integral" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-black uppercase tracking-wide text-slate-600">Deskripsi</label>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className="focus-ring w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm" />
          </div>
        </div>
        {error && <p className="mt-3 rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        <div className="mt-5 flex gap-2">
          <Button onClick={save} disabled={saving} className="flex-1 rounded-2xl">
            {saving ? 'Menyimpan...' : 'Simpan'}
          </Button>
          <Button onClick={onClose} variant="outline" className="rounded-2xl">Batal</Button>
        </div>
      </div>
    </div>
  )
}
