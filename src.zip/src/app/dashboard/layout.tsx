import { redirect } from 'next/navigation'
import AppShell from '@/components/AppShell'
import DashboardSuccessToast from '@/components/DashboardSuccessToast'
import PwaInstallBanner from '@/components/PwaInstallBanner'
import { createClient } from '@/lib/supabase/server'
import type { Profile } from '@/types'
import { getEffectivePlan } from '@/lib/plans'
import { Suspense, type ReactNode } from 'react'

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect('/login')
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('full_name, email, plan, pulse_trial_until, plan_expires_at, subscription_expires_at, command_expires_at, lifetime_command, profile_completed, avatar_url, nexa_id')
    .eq('id', user.id)
    .maybeSingle()

  const userName =
    profile?.full_name ||
    user.user_metadata?.full_name ||
    user.user_metadata?.name ||
    user.email?.split('@')[0] ||
    null

  return (
    <AppShell
      profile={{
        plan: getEffectivePlan({ ...(profile ?? {}), email: user.email }),
        full_name: userName,
        avatar_url: (profile as { avatar_url?: string | null } | null)?.avatar_url ?? null,
        email: user.email ?? null,
        nexa_id: (profile as { nexa_id?: string | null } | null)?.nexa_id ?? null,
      }}
    >
      {children}
      <Suspense fallback={null}>
        <DashboardSuccessToast />
      </Suspense>
      <PwaInstallBanner />
    </AppShell>
  )
}
