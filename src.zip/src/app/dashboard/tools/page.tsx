'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import {
  BadgeCheck, BarChart3, BookMarked, Bot, BriefcaseBusiness,
  CalendarClock, CheckCircle2, ClipboardCheck, FileSearch,
  GraduationCap, HeartPulse, LineChart, Lock, MessageSquareText,
  Network, PenTool, PiggyBank, Sparkles, Users, ArrowLeft,
  Loader2, Send, Plus, Trash2, ChevronRight, Star,
} from 'lucide-react'
import Button from '@/components/ui/Button'

type Plan = 'Free' | 'Basic' | 'Pro'
type ToolId =
  | 'ai-ringkas' | 'flashcard' | 'deadline-risk' | 'ipk-planner'
  | 'citation' | 'group-board' | 'scholarship' | 'career'
  | 'event-hub' | 'thesis' | 'exam-readiness' | 'mental-load'
  | 'anti-plagiarism' | 'ai-mentor' | 'analytics'

interface Tool {
  id: ToolId
  title: string
  icon: React.ElementType
  plan: Plan
  desc: string
  emoji: string
}

const TOOLS: Tool[] = [
  { id: 'ai-ringkas',      title: 'AI Ringkas Materi',    icon: Bot,              plan: 'Free',  emoji: '🤖', desc: 'Ubah catatan panjang jadi ringkasan terstruktur dengan AI.' },
  { id: 'flashcard',       title: 'Flashcard Generator',  icon: BookMarked,       plan: 'Free',  emoji: '🃏', desc: 'Generate kartu tanya-jawab dari topik kuliah secara otomatis.' },
  { id: 'deadline-risk',   title: 'Deadline Risk Score',  icon: CalendarClock,    plan: 'Free',  emoji: '⏰', desc: 'Hitung skor risiko keterlambatan tugas secara real-time.' },
  { id: 'ipk-planner',     title: 'IPK Planner',          icon: LineChart,        plan: 'Free',  emoji: '📊', desc: 'Simulasi target IPK dan nilai tiap mata kuliah.' },
  { id: 'citation',        title: 'Citation Builder',     icon: PenTool,          plan: 'Free',  emoji: '📝', desc: 'Buat sitasi APA/MLA/Chicago otomatis.' },
  { id: 'group-board',     title: 'Group Project Board',  icon: Users,            plan: 'Free',  emoji: '👥', desc: 'Manajemen peran dan deadline kerja kelompok.' },
  { id: 'scholarship',     title: 'Scholarship Radar',    icon: PiggyBank,        plan: 'Basic', emoji: '🎓', desc: 'Checklist dan strategi persiapan beasiswa.' },
  { id: 'career',          title: 'Career Launchpad',     icon: BriefcaseBusiness,plan: 'Basic', emoji: '🚀', desc: 'Roadmap skill dan portofolio menuju karir impian.' },
  { id: 'event-hub',       title: 'Campus Event Hub',     icon: Network,          plan: 'Basic', emoji: '📅', desc: 'Kurasi agenda kampus, seminar, dan kompetisi.' },
  { id: 'thesis',          title: 'Thesis Compass',       icon: GraduationCap,    plan: 'Basic', emoji: '🧭', desc: 'Bantu pecah ide skripsi jadi milestone terstruktur.' },
  { id: 'exam-readiness',  title: 'Exam Readiness',       icon: ClipboardCheck,   plan: 'Basic', emoji: '✅', desc: 'Cek kesiapan ujian dari berbagai faktor.' },
  { id: 'mental-load',     title: 'Mental Load Check',    icon: HeartPulse,       plan: 'Basic', emoji: '💚', desc: 'Pantau beban akademik dan kesehatan mental.' },
  { id: 'anti-plagiarism', title: 'Anti Plagiarism Prep', icon: FileSearch,       plan: 'Pro',   emoji: '🔍', desc: 'Checklist parafrase dan sumber sebelum submit.' },
  { id: 'ai-mentor',       title: 'AI Mentor Chat',       icon: MessageSquareText,plan: 'Pro',   emoji: '💬', desc: 'Sesi belajar personal dengan AI tutor adaptif.' },
  { id: 'analytics',       title: 'Campus Analytics',     icon: BarChart3,        plan: 'Pro',   emoji: '📈', desc: 'Dashboard performa belajar lintas semua modul.' },
]

const PLAN_STYLE: Record<Plan, { badge: string; ring: string }> = {
  Free:  { badge: 'bg-emerald-100 text-emerald-700 border-emerald-200',  ring: 'ring-emerald-400' },
  Basic: { badge: 'bg-blue-100 text-blue-700 border-blue-200',           ring: 'ring-blue-400' },
  Pro:   { badge: 'bg-violet-100 text-violet-700 border-violet-200',     ring: 'ring-violet-400' },
}

// ─── Individual Tool UIs ────────────────────────────────────────────────────

function AiRingkasUI() {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [loading, setLoading] = useState(false)

  async function run() {
    if (!input.trim()) return
    setLoading(true); setOutput('')
    try {
      const res = await fetch('/api/anthropic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Kamu adalah tutor mahasiswa Indonesia. Buatkan ringkasan terstruktur dari materi berikut dalam Bahasa Indonesia. Format: 
**Konsep Utama**, **Poin-Poin Penting** (5-7 poin), **Contoh Aplikasi**, **Yang Sering Keluar Ujian**.

Materi:
${input}`,
        }),
      })
      const data = await res.json()
      setOutput(data.result || data.error || 'Terjadi kesalahan.')
    } catch { setOutput('Gagal menghubungi AI.') }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">Paste materi / catatan kuliah</label>
        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          rows={6}
          placeholder="Tempel materi kuliah, catatan, atau teks panjang di sini..."
          className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-brand-400"
        />
      </div>
      <Button onClick={run} disabled={loading || !input.trim()} className="w-full">
        {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Meringkas...</> : <><Sparkles className="w-4 h-4" /> Ringkas dengan AI</>}
      </Button>
      {output && (
        <div className="rounded-xl bg-slate-50 border border-slate-200 p-5">
          <p className="text-sm font-bold text-slate-700 mb-3">✨ Hasil Ringkasan</p>
          <div className="prose prose-sm max-w-none text-slate-700 whitespace-pre-wrap text-sm leading-7">{output}</div>
        </div>
      )}
    </div>
  )
}

function FlashcardUI() {
  const [topic, setTopic] = useState('')
  const [cards, setCards] = useState<{ q: string; a: string }[]>([])
  const [flipped, setFlipped] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)

  async function generate() {
    if (!topic.trim()) return
    setLoading(true); setCards([]); setFlipped(null)
    try {
      const res = await fetch('/api/anthropic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Buat 8 flashcard tanya-jawab untuk topik "${topic}" dalam Bahasa Indonesia. Cocok untuk ujian mahasiswa.
Balas HANYA dengan JSON array, tanpa teks lain:
[{"q":"pertanyaan","a":"jawaban singkat padat"}]`,
        }),
      })
      const data = await res.json()
      const text = data.result || ''
      const match = text.match(/\[[\s\S]*\]/)
      if (match) setCards(JSON.parse(match[0]))
    } catch { /* silent */ }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-3">
        <input
          value={topic}
          onChange={e => setTopic(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && generate()}
          placeholder="Topik kuliah, misal: Hukum Newton, Akuntansi Biaya..."
          className="flex-1 rounded-xl border border-slate-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400"
        />
        <Button onClick={generate} disabled={loading || !topic.trim()}>
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><BookMarked className="w-4 h-4" /> Buat</>}
        </Button>
      </div>
      {cards.length > 0 && (
        <div className="grid sm:grid-cols-2 gap-3">
          {cards.map((card, i) => (
            <button
              key={i}
              onClick={() => setFlipped(flipped === i ? null : i)}
              className={`rounded-xl border-2 p-4 text-left transition-all duration-200 ${flipped === i ? 'border-brand-400 bg-brand-50' : 'border-slate-200 bg-white hover:border-brand-200'}`}
            >
              <p className="text-xs font-bold text-slate-400 mb-1">{flipped === i ? '💡 JAWABAN' : '❓ PERTANYAAN'}</p>
              <p className="text-sm text-slate-800 font-medium">{flipped === i ? card.a : card.q}</p>
              <p className="text-xs text-brand-500 mt-2">{flipped === i ? 'Klik untuk balik' : 'Klik untuk lihat jawaban'}</p>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function DeadlineRiskUI() {
  const [tasks, setTasks] = useState([
    { name: 'Makalah Ekonomi', daysLeft: 3, progress: 40, weight: 30 },
    { name: 'UTS Statistik', daysLeft: 7, progress: 60, weight: 25 },
  ])

  function addTask() {
    setTasks([...tasks, { name: 'Tugas Baru', daysLeft: 5, progress: 0, weight: 20 }])
  }
  function removeTask(i: number) { setTasks(tasks.filter((_, idx) => idx !== i)) }
  function update(i: number, field: string, val: string | number) {
    setTasks(tasks.map((t, idx) => idx === i ? { ...t, [field]: val } : t))
  }

  function calcRisk(daysLeft: number, progress: number) {
    const urgency = Math.max(0, 100 - daysLeft * 12)
    const missing = Math.max(0, 100 - progress)
    return Math.min(100, Math.round(urgency * 0.55 + missing * 0.45))
  }

  const getRiskColor = (r: number) =>
    r > 70 ? 'text-red-600 bg-red-50 border-red-200' :
    r > 40 ? 'text-amber-600 bg-amber-50 border-amber-200' :
    'text-emerald-600 bg-emerald-50 border-emerald-200'

  return (
    <div className="space-y-4">
      {tasks.map((task, i) => {
        const risk = calcRisk(task.daysLeft, task.progress)
        return (
          <div key={i} className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex items-center gap-3 mb-3">
              <input
                value={task.name}
                onChange={e => update(i, 'name', e.target.value)}
                className="flex-1 text-sm font-semibold text-slate-800 border-0 focus:outline-none bg-transparent"
              />
              <span className={`px-3 py-1 rounded-full text-xs font-black border ${getRiskColor(risk)}`}>
                Risk {risk}
              </span>
              <button onClick={() => removeTask(i)} className="text-slate-300 hover:text-red-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-4 text-xs">
              <label className="space-y-1 text-slate-500 font-medium">
                Sisa Hari: <span className="text-slate-800 font-bold">{task.daysLeft}</span>
                <input type="range" min="0" max="30" value={task.daysLeft}
                  onChange={e => update(i, 'daysLeft', Number(e.target.value))}
                  className="w-full block" />
              </label>
              <label className="space-y-1 text-slate-500 font-medium">
                Progres: <span className="text-slate-800 font-bold">{task.progress}%</span>
                <input type="range" min="0" max="100" value={task.progress}
                  onChange={e => update(i, 'progress', Number(e.target.value))}
                  className="w-full block" />
              </label>
              <label className="space-y-1 text-slate-500 font-medium">
                Bobot: <span className="text-slate-800 font-bold">{task.weight}%</span>
                <input type="range" min="5" max="50" value={task.weight}
                  onChange={e => update(i, 'weight', Number(e.target.value))}
                  className="w-full block" />
              </label>
            </div>
            <div className="mt-3 bg-slate-100 rounded-full h-2">
              <div className={`h-2 rounded-full transition-all ${risk > 70 ? 'bg-red-500' : risk > 40 ? 'bg-amber-400' : 'bg-emerald-500'}`}
                style={{ width: `${risk}%` }} />
            </div>
          </div>
        )
      })}
      <button onClick={addTask} className="w-full rounded-xl border-2 border-dashed border-slate-300 py-3 text-sm text-slate-400 hover:border-brand-300 hover:text-brand-500 transition-colors flex items-center justify-center gap-2">
        <Plus className="w-4 h-4" /> Tambah Tugas
      </button>
    </div>
  )
}

function IpkPlannerUI() {
  const [matkul, setMatkul] = useState([
    { nama: 'Kalkulus', sks: 3, target: 'A' },
    { nama: 'Bahasa Indonesia', sks: 2, target: 'A' },
    { nama: 'Fisika Dasar', sks: 4, target: 'B+' },
    { nama: 'Pemrograman', sks: 3, target: 'A' },
  ])

  const nilaiMap: Record<string, number> = { 'A': 4.0, 'A-': 3.7, 'B+': 3.3, 'B': 3.0, 'B-': 2.7, 'C+': 2.3, 'C': 2.0, 'D': 1.0, 'E': 0 }
  const grades = Object.keys(nilaiMap)

  function addMatkul() { setMatkul([...matkul, { nama: 'Mata Kuliah Baru', sks: 3, target: 'B+' }]) }
  function remove(i: number) { setMatkul(matkul.filter((_, idx) => idx !== i)) }
  function update(i: number, f: string, v: string | number) {
    setMatkul(matkul.map((m, idx) => idx === i ? { ...m, [f]: v } : m))
  }

  const totalSks = matkul.reduce((s, m) => s + m.sks, 0)
  const ipk = totalSks > 0
    ? matkul.reduce((s, m) => s + (nilaiMap[m.target] || 0) * m.sks, 0) / totalSks
    : 0
  const ipkColor = ipk >= 3.5 ? 'text-emerald-600' : ipk >= 3.0 ? 'text-blue-600' : ipk >= 2.5 ? 'text-amber-600' : 'text-red-600'

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between bg-slate-950 text-white rounded-xl p-5">
        <div>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-wide">Proyeksi IPK</p>
          <p className={`text-5xl font-black mt-1 ${ipkColor.replace('text-', 'text-')}`} style={{ color: ipk >= 3.5 ? '#34d399' : ipk >= 3.0 ? '#60a5fa' : ipk >= 2.5 ? '#fbbf24' : '#f87171' }}>
            {ipk.toFixed(2)}
          </p>
        </div>
        <div className="text-right text-sm text-slate-300">
          <p>{totalSks} SKS total</p>
          <p>{matkul.length} mata kuliah</p>
        </div>
      </div>

      <div className="space-y-2">
        {matkul.map((m, i) => (
          <div key={i} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 bg-white">
            <input value={m.nama} onChange={e => update(i, 'nama', e.target.value)}
              className="flex-1 text-sm text-slate-800 border-0 focus:outline-none bg-transparent font-medium min-w-0" />
            <select value={m.sks} onChange={e => update(i, 'sks', Number(e.target.value))}
              className="text-xs border border-slate-200 rounded-lg px-2 py-1 bg-white text-slate-700">
              {[1,2,3,4,6].map(s => <option key={s} value={s}>{s} SKS</option>)}
            </select>
            <select value={m.target} onChange={e => update(i, 'target', e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2 py-1 bg-white font-bold text-slate-800">
              {grades.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
            <span className="text-xs text-slate-400 w-8 text-right">{nilaiMap[m.target]?.toFixed(1)}</span>
            <button onClick={() => remove(i)} className="text-slate-300 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
          </div>
        ))}
      </div>
      <button onClick={addMatkul} className="w-full rounded-xl border-2 border-dashed border-slate-300 py-3 text-sm text-slate-400 hover:border-brand-300 hover:text-brand-500 transition-colors flex items-center justify-center gap-2">
        <Plus className="w-4 h-4" /> Tambah Mata Kuliah
      </button>
    </div>
  )
}

function CitationUI() {
  const [type, setType] = useState<'jurnal' | 'buku' | 'web'>('jurnal')
  const [fields, setFields] = useState({ penulis: '', tahun: '', judul: '', jurnal: '', volume: '', halaman: '', penerbit: '', kota: '', url: '', diakses: '' })
  const [style, setStyle] = useState<'APA' | 'MLA' | 'Chicago'>('APA')
  const [result, setResult] = useState('')
  const [copied, setCopied] = useState(false)

  function set(f: string, v: string) { setFields(prev => ({ ...prev, [f]: v })) }

  function generate() {
    const { penulis, tahun, judul, jurnal, volume, halaman, penerbit, kota, url, diakses } = fields
    let citation = ''
    if (style === 'APA') {
      if (type === 'jurnal') citation = `${penulis} (${tahun}). ${judul}. *${jurnal}*, *${volume}*, ${halaman}.`
      else if (type === 'buku') citation = `${penulis} (${tahun}). *${judul}*. ${penerbit}.`
      else citation = `${penulis} (${tahun}). *${judul}*. Diambil dari ${url} (diakses ${diakses})`
    } else if (style === 'MLA') {
      if (type === 'jurnal') citation = `${penulis}. "${judul}." *${jurnal}*, vol. ${volume}, ${tahun}, pp. ${halaman}.`
      else if (type === 'buku') citation = `${penulis}. *${judul}*. ${penerbit}, ${tahun}.`
      else citation = `${penulis}. "${judul}." *Web*, ${tahun}, ${url}. Diakses ${diakses}.`
    } else {
      if (type === 'jurnal') citation = `${penulis}. "${judul}." *${jurnal}* ${volume} (${tahun}): ${halaman}.`
      else if (type === 'buku') citation = `${penulis}. *${judul}*. ${kota}: ${penerbit}, ${tahun}.`
      else citation = `${penulis}. "${judul}." Diakses ${diakses}. ${url}.`
    }
    setResult(citation)
  }

  function copy() { navigator.clipboard.writeText(result.replace(/\*/g, '')); setCopied(true); setTimeout(() => setCopied(false), 2000) }

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        {(['jurnal', 'buku', 'web'] as const).map(t => (
          <button key={t} onClick={() => setType(t)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold border transition ${type === t ? 'bg-brand-600 text-white border-brand-600' : 'border-slate-300 text-slate-600 hover:border-brand-300'}`}>
            {t === 'jurnal' ? '📄 Jurnal' : t === 'buku' ? '📚 Buku' : '🌐 Website'}
          </button>
        ))}
        <div className="ml-auto flex gap-2">
          {(['APA', 'MLA', 'Chicago'] as const).map(s => (
            <button key={s} onClick={() => setStyle(s)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold border transition ${style === s ? 'bg-slate-900 text-white border-slate-900' : 'border-slate-300 text-slate-600'}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        {[
          { f: 'penulis', label: 'Penulis (Nama, Inisial.)', show: true },
          { f: 'tahun', label: 'Tahun Terbit', show: true },
          { f: 'judul', label: 'Judul Artikel/Buku', show: true },
          { f: 'jurnal', label: 'Nama Jurnal', show: type === 'jurnal' },
          { f: 'volume', label: 'Volume', show: type === 'jurnal' },
          { f: 'halaman', label: 'Halaman (mis: 12-24)', show: type === 'jurnal' },
          { f: 'penerbit', label: 'Penerbit', show: type === 'buku' },
          { f: 'kota', label: 'Kota Terbit', show: type === 'buku' && style === 'Chicago' },
          { f: 'url', label: 'URL', show: type === 'web' },
          { f: 'diakses', label: 'Tanggal Diakses', show: type === 'web' },
        ].filter(x => x.show).map(({ f, label }) => (
          <div key={f}>
            <label className="block text-xs font-semibold text-slate-600 mb-1">{label}</label>
            <input value={(fields as Record<string, string>)[f]} onChange={e => set(f, e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
          </div>
        ))}
      </div>

      <Button onClick={generate} className="w-full"><PenTool className="w-4 h-4" /> Generate Sitasi</Button>

      {result && (
        <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 relative">
          <p className="text-xs font-bold text-slate-400 mb-2">{style} — {type}</p>
          <p className="text-sm text-slate-800 italic leading-7">{result.replace(/\*/g, '')}</p>
          <button onClick={copy}
            className="absolute top-3 right-3 text-xs px-3 py-1 rounded-lg bg-white border border-slate-200 text-slate-600 hover:border-brand-300 hover:text-brand-600 transition">
            {copied ? '✓ Tersalin!' : 'Salin'}
          </button>
        </div>
      )}
    </div>
  )
}

function GroupBoardUI() {
  const [members, setMembers] = useState([
    { nama: 'Andi', peran: 'Ketua', task: 'Bab 1 & 2', status: 'done', deadline: '2025-06-10' },
    { nama: 'Bella', peran: 'Sekretaris', task: 'Slide presentasi', status: 'inprogress', deadline: '2025-06-12' },
    { nama: 'Ciko', peran: 'Anggota', task: 'Bab 3 & Penutup', status: 'todo', deadline: '2025-06-14' },
  ])

  const statusConfig: Record<string, { label: string; color: string }> = {
    done: { label: '✅ Selesai', color: 'bg-emerald-100 text-emerald-700' },
    inprogress: { label: '🔄 Sedang', color: 'bg-blue-100 text-blue-700' },
    todo: { label: '⏳ Belum', color: 'bg-slate-100 text-slate-600' },
  }

  function update(i: number, f: string, v: string) { setMembers(members.map((m, idx) => idx === i ? { ...m, [f]: v } : m)) }
  function add() { setMembers([...members, { nama: 'Anggota Baru', peran: 'Anggota', task: '', status: 'todo', deadline: '' }]) }
  function remove(i: number) { setMembers(members.filter((_, idx) => idx !== i)) }

  const done = members.filter(m => m.status === 'done').length
  const pct = members.length > 0 ? Math.round(done / members.length * 100) : 0

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4 bg-slate-950 text-white rounded-xl p-4">
        <div className="flex-1">
          <p className="text-xs text-slate-400 font-bold uppercase tracking-wide mb-2">Progress Kelompok</p>
          <div className="bg-slate-800 rounded-full h-3">
            <div className="bg-emerald-400 h-3 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
          </div>
        </div>
        <p className="text-2xl font-black text-emerald-400">{pct}%</p>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200">
              {['Nama', 'Peran', 'Tugas', 'Deadline', 'Status', ''].map(h => (
                <th key={h} className="text-left py-2 px-2 text-xs font-bold text-slate-400 uppercase">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {members.map((m, i) => (
              <tr key={i} className="hover:bg-slate-50">
                <td className="py-2 px-2"><input value={m.nama} onChange={e => update(i, 'nama', e.target.value)} className="text-sm font-semibold text-slate-800 border-0 focus:outline-none bg-transparent w-20" /></td>
                <td className="py-2 px-2"><input value={m.peran} onChange={e => update(i, 'peran', e.target.value)} className="text-xs text-slate-500 border-0 focus:outline-none bg-transparent w-20" /></td>
                <td className="py-2 px-2"><input value={m.task} onChange={e => update(i, 'task', e.target.value)} className="text-xs text-slate-700 border-0 focus:outline-none bg-transparent w-28" /></td>
                <td className="py-2 px-2"><input type="date" value={m.deadline} onChange={e => update(i, 'deadline', e.target.value)} className="text-xs border-0 focus:outline-none bg-transparent" /></td>
                <td className="py-2 px-2">
                  <select value={m.status} onChange={e => update(i, 'status', e.target.value)}
                    className={`text-xs rounded-full px-2 py-0.5 font-semibold border-0 ${statusConfig[m.status].color}`}>
                    <option value="todo">Belum</option>
                    <option value="inprogress">Sedang</option>
                    <option value="done">Selesai</option>
                  </select>
                </td>
                <td className="py-2 px-2"><button onClick={() => remove(i)} className="text-slate-300 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button onClick={add} className="w-full rounded-xl border-2 border-dashed border-slate-300 py-3 text-sm text-slate-400 hover:border-brand-300 hover:text-brand-500 transition-colors flex items-center justify-center gap-2">
        <Plus className="w-4 h-4" /> Tambah Anggota
      </button>
    </div>
  )
}

function AiMentorUI() {
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
    { role: 'assistant', content: 'Halo! Aku AI Mentor kamu. Mau belajar topik apa hari ini? Ceritakan juga level pemahamanmu saat ini. 🎓' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  async function send() {
    if (!input.trim() || loading) return
    const userMsg = input.trim()
    setInput('')
    const newMsgs = [...messages, { role: 'user' as const, content: userMsg }]
    setMessages(newMsgs)
    setLoading(true)
    try {
      const res = await fetch('/api/anthropic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: 'Kamu adalah AI Mentor untuk mahasiswa Indonesia. Berikan penjelasan yang ramah, terstruktur, dan mudah dipahami. Gunakan analogi sederhana. Selalu tanya apakah penjelasanmu sudah jelas.',
          messages: newMsgs.map(m => ({ role: m.role, content: m.content })),
        }),
      })
      const data = await res.json()
      setMessages([...newMsgs, { role: 'assistant', content: data.result || 'Maaf, ada masalah teknis.' }])
    } catch {
      setMessages([...newMsgs, { role: 'assistant', content: 'Koneksi bermasalah. Coba lagi.' }])
    }
    setLoading(false)
  }

  return (
    <div className="flex flex-col h-96">
      <div className="flex-1 overflow-y-auto space-y-3 mb-4 pr-1">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-6 ${m.role === 'user' ? 'bg-brand-600 text-white rounded-br-sm' : 'bg-slate-100 text-slate-800 rounded-bl-sm'}`}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-100 rounded-2xl rounded-bl-sm px-4 py-3">
              <Loader2 className="w-4 h-4 text-slate-400 animate-spin" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="flex gap-2">
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          placeholder="Tanya apapun tentang pelajaran..."
          className="flex-1 rounded-xl border border-slate-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
        <Button onClick={send} disabled={loading || !input.trim()}>
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}

function GenericAiUI({ toolId, title }: { toolId: ToolId; title: string }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [loading, setLoading] = useState(false)

  const prompts: Partial<Record<ToolId, string>> = {
    'scholarship': 'Kamu adalah konsultan beasiswa Indonesia. Berikan checklist persiapan beasiswa yang komprehensif, tips seleksi, dan prioritas dokumen untuk: ',
    'career': 'Kamu adalah career advisor untuk mahasiswa Indonesia. Buat roadmap karir, daftar skill yang perlu dikuasai, dan saran portofolio untuk jurusan/bidang: ',
    'event-hub': 'Kamu adalah kurator event kampus Indonesia. Berikan daftar kompetisi, seminar, program volunteer, dan agenda organisasi yang relevan untuk mahasiswa jurusan: ',
    'thesis': 'Kamu adalah dosen pembimbing skripsi Indonesia. Bantu pecah ide penelitian berikut menjadi rumusan masalah, tujuan, metodologi, dan milestone: ',
    'exam-readiness': 'Kamu adalah konsultan belajar. Analisis kesiapan ujian dan berikan strategi belajar optimal untuk: ',
    'mental-load': 'Kamu adalah konselor kampus yang empatik. Analisis beban akademik dan berikan strategi manajemen stres, jadwal istirahat, dan tips self-care untuk situasi: ',
    'anti-plagiarism': 'Kamu adalah editor akademik Indonesia. Berikan checklist anti-plagiarisme, panduan parafrase yang benar, dan cara cek sumber untuk topik: ',
    'analytics': 'Kamu adalah akademik advisor. Analisis dan berikan insight serta rekomendasi perbaikan dari data akademik berikut: ',
  }

  const placeholders: Partial<Record<ToolId, string>> = {
    'scholarship': 'Ceritakan profil kamu: jurusan, IPK, prestasi, target beasiswa...',
    'career': 'Tuliskan jurusan, skill yang sudah dimiliki, dan karir yang dituju...',
    'event-hub': 'Tuliskan jurusan dan minat kamu...',
    'thesis': 'Tuliskan ide atau topik skripsi kamu...',
    'exam-readiness': 'Tuliskan mata kuliah, topik yang sudah dipelajari, dan yang belum...',
    'mental-load': 'Ceritakan kondisi akademik dan perasaan kamu saat ini...',
    'anti-plagiarism': 'Tuliskan topik paper dan bagian yang ingin dicek...',
    'analytics': 'Paste data nilai, presensi, atau aktivitas belajar kamu...',
  }

  async function run() {
    if (!input.trim()) return
    setLoading(true); setOutput('')
    try {
      const systemPrompt = prompts[toolId] || `Kamu adalah asisten akademik Indonesia untuk fitur "${title}". Bantu mahasiswa dengan:`
      const res = await fetch('/api/anthropic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: systemPrompt + '\n\n' + input }),
      })
      const data = await res.json()
      setOutput(data.result || data.error || 'Terjadi kesalahan.')
    } catch { setOutput('Gagal menghubungi AI.') }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <textarea value={input} onChange={e => setInput(e.target.value)} rows={5}
        placeholder={placeholders[toolId] || `Ceritakan situasimu untuk ${title}...`}
        className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-brand-400" />
      <Button onClick={run} disabled={loading || !input.trim()} className="w-full">
        {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</> : <><Sparkles className="w-4 h-4" /> Jalankan {title}</>}
      </Button>
      {output && (
        <div className="rounded-xl bg-slate-50 border border-slate-200 p-5">
          <p className="text-sm font-bold text-slate-700 mb-3">✨ Hasil Analisis</p>
          <div className="text-sm text-slate-700 whitespace-pre-wrap leading-7">{output}</div>
        </div>
      )}
    </div>
  )
}

// ─── Tool Detail View ────────────────────────────────────────────────────────

function ToolDetail({ tool, onBack }: { tool: Tool; onBack: () => void }) {
  const Icon = tool.icon
  const planStyle = PLAN_STYLE[tool.plan]

  const renderUI = () => {
    switch (tool.id) {
      case 'ai-ringkas':     return <AiRingkasUI />
      case 'flashcard':      return <FlashcardUI />
      case 'deadline-risk':  return <DeadlineRiskUI />
      case 'ipk-planner':    return <IpkPlannerUI />
      case 'citation':       return <CitationUI />
      case 'group-board':    return <GroupBoardUI />
      case 'ai-mentor':      return <AiMentorUI />
      default:               return <GenericAiUI toolId={tool.id} title={tool.title} />
    }
  }

  const isPro = tool.plan === 'Pro'

  return (
    <div className="space-y-6 animate-fade-in">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-800 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Kembali ke Campus Tools
      </button>

      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-brand-50 flex items-center justify-center text-brand-600 flex-shrink-0">
            <Icon className="w-7 h-7" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap mb-2">
              <h1 className="text-2xl font-black text-slate-950">{tool.title}</h1>
              <span className={`text-xs font-black px-2.5 py-1 rounded-full border ${planStyle.badge}`}>{tool.plan}</span>
              {isPro && (
                <span className="flex items-center gap-1 text-xs font-bold text-violet-600 bg-violet-50 border border-violet-200 px-2 py-0.5 rounded-full">
                  <Lock className="w-3 h-3" /> Pro Feature
                </span>
              )}
            </div>
            <p className="text-slate-500 text-sm leading-6">{tool.desc}</p>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        {isPro ? (
          <div className="text-center py-10">
            <div className="w-16 h-16 rounded-2xl bg-violet-50 flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-violet-400" />
            </div>
            <h3 className="font-black text-slate-900 text-lg mb-2">Fitur Pro</h3>
            <p className="text-slate-500 text-sm mb-5 max-w-xs mx-auto">Upgrade ke paket Pro (Rp25.000/bulan) untuk akses ke {tool.title} dan semua fitur premium lainnya.</p>
            <Link href="/pricing"><Button><Star className="w-4 h-4" /> Upgrade ke Pro</Button></Link>
          </div>
        ) : renderUI()}
      </div>
    </div>
  )
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export default function CampusToolsPage() {
  const [activeTool, setActiveTool] = useState<Tool | null>(null)
  const [filterPlan, setFilterPlan] = useState<Plan | 'Semua'>('Semua')

  if (activeTool) return <ToolDetail tool={activeTool} onBack={() => setActiveTool(null)} />

  const filtered = filterPlan === 'Semua' ? TOOLS : TOOLS.filter(t => t.plan === filterPlan)
  const grouped = {
    Free: filtered.filter(t => t.plan === 'Free'),
    Basic: filtered.filter(t => t.plan === 'Basic'),
    Pro: filtered.filter(t => t.plan === 'Pro'),
  }

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section className="rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-brand-950 text-white p-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-brand-500/20 via-transparent to-transparent pointer-events-none" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-500/10 px-3 py-1 text-xs font-bold text-brand-300">
              <Sparkles className="h-3.5 w-3.5" /> Campus Tools
            </div>
            <h1 className="text-3xl font-black tracking-tight md:text-4xl">
              15 tools produktivitas.<br />
              <span className="text-brand-300">Semuanya bisa dipakai langsung.</span>
            </h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-slate-300">
              Dari ringkasan AI, flashcard generator, planner IPK, sampai AI mentor chat — semua powered by AI, siap dipakai sekarang.
            </p>
          </div>
          <Link href="/pricing" className="flex-shrink-0">
            <Button className="bg-white text-slate-900 hover:bg-slate-100">
              <BadgeCheck className="h-4 w-4" /> Lihat Paket
            </Button>
          </Link>
        </div>
      </section>

      {/* Filter */}
      <div className="flex gap-2 flex-wrap">
        {(['Semua', 'Free', 'Basic', 'Pro'] as const).map(f => (
          <button key={f} onClick={() => setFilterPlan(f)}
            className={`px-4 py-2 rounded-full text-sm font-bold border transition-all ${filterPlan === f
              ? f === 'Free' ? 'bg-emerald-500 text-white border-emerald-500'
              : f === 'Basic' ? 'bg-blue-500 text-white border-blue-500'
              : f === 'Pro' ? 'bg-violet-500 text-white border-violet-500'
              : 'bg-slate-900 text-white border-slate-900'
              : 'border-slate-300 text-slate-600 hover:border-slate-400 bg-white'}`}>
            {f === 'Semua' ? '⚡ Semua' : f === 'Free' ? '🆓 Free' : f === 'Basic' ? '💎 Basic' : '👑 Pro'}
          </button>
        ))}
        <span className="ml-auto text-sm text-slate-400 self-center">{filtered.length} tools</span>
      </div>

      {/* Tool Groups */}
      {(['Free', 'Basic', 'Pro'] as const).map(plan => {
        const tools = grouped[plan]
        if (tools.length === 0) return null
        const groupStyle = PLAN_STYLE[plan]
        return (
          <section key={plan}>
            <div className="flex items-center gap-3 mb-4">
              <span className={`text-xs font-black px-3 py-1 rounded-full border ${groupStyle.badge}`}>
                {plan === 'Free' ? '🆓' : plan === 'Basic' ? '💎' : '👑'} {plan}
              </span>
              <div className="h-px flex-1 bg-slate-200" />
              <span className="text-xs text-slate-400">{tools.length} tools</span>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {tools.map(tool => {
                const Icon = tool.icon
                return (
                  <button
                    key={tool.id}
                    onClick={() => setActiveTool(tool)}
                    className="group rounded-2xl border-2 border-slate-200 bg-white p-5 text-left hover:border-brand-300 hover:shadow-md transition-all duration-200 relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-brand-50/0 to-brand-50/0 group-hover:from-brand-50/50 group-hover:to-transparent transition-all duration-200 pointer-events-none" />
                    <div className="relative">
                      <div className="flex items-start justify-between mb-4">
                        <div className="w-11 h-11 rounded-xl bg-slate-100 group-hover:bg-brand-100 flex items-center justify-center text-slate-500 group-hover:text-brand-600 transition-colors">
                          <Icon className="w-5 h-5" />
                        </div>
                        {plan === 'Pro' && <Lock className="w-4 h-4 text-violet-400" />}
                      </div>
                      <h3 className="font-black text-slate-900 mb-1.5">{tool.title}</h3>
                      <p className="text-xs text-slate-500 leading-5 mb-4">{tool.desc}</p>
                      <div className="flex items-center text-xs font-bold text-brand-600 group-hover:gap-2 transition-all">
                        <span>Buka Tool</span>
                        <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          </section>
        )
      })}
    </div>
  )
}